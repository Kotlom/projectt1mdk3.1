module org.example.pr2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens org.example.pr2 to javafx.fxml;
    exports org.example.pr2;
}